﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace AdminApiConsume.Controllers
{
    public class TrainingController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Get()
        {
            return View();
        }
        public IActionResult Post()
        {
            return View();
        }
        public IActionResult Put()
        {
            return View();
        }
        public IActionResult Delete()
        {
            return View();
        }
    }
}