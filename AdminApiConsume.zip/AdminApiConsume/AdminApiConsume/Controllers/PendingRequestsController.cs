﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using AdminApi.Models;

namespace AdminApiConsume.Controllers
{
    public class PendingRequestsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Get()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:49374/api/");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage res = client.GetAsync("PendingRequests").Result;
            if (res.IsSuccessStatusCode)
            {
                ViewBag.res = res.Content.ReadAsAsync<IEnumerable<UserDetail>>().Result;

            }
            else
            {
                ViewBag.res = "Error";
            }
            return View();

        }

        //[HttpGet]
        //public IActionResult Getuser(int Id)
        //{
        //    return View();
        //}
        [HttpGet]
        public IActionResult put(int id)
        {
            ViewBag.id = id;
            return View();
        }
    }
}