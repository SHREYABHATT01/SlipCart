﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewAdminApi.Models;

namespace NewAdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Supplier")]
    public class SupplierController : Controller
    {
        private readonly SlipCartDatabaseContext db;
        public SupplierController(SlipCartDatabaseContext context)
        {
            db = context;
        }

        public List<Supplier> SupplierGet()
        {
            var data = from x in db.Supplier select x;
            return data.ToList();
        }



        [HttpPut("{SuppID}")]
        public IActionResult SupplierPut(int? SuppID,[FromBody] Supplier sup)
        {
            if (SuppID == null)
            {
                return NotFound();
            }

            var obj = db.Supplier.Find(SuppID);
            if (obj == null)
            {
                return NotFound();
            }
            else
            {
                //obj.SuppCode = sup.SuppCode;
                obj.SuppName = sup.SuppName;
                obj.SuppAddress = sup.SuppAddress;
                obj.SuppPhone = sup.SuppPhone;
                obj.SuppPassword = sup.SuppPassword;
                obj.SuppEmailId = sup.SuppEmailId;
                obj.CreatedDate = sup.CreatedDate;
                obj.CreatedBy = sup.CreatedBy;
                obj.UpdatedDate = sup.UpdatedDate;
                obj.UpdatedBy = sup.UpdatedBy;
                obj.IsActive = sup.IsActive;
                db.SaveChanges();
                return new ObjectResult("Edited successfully");
            }
        }
        [HttpGet("{SuppID}")]
        public List<Supplier> GetSup(int? SuppID)
        {


            var sup = db.Supplier.Select(ss => ss).Where(ss => ss.SuppId == SuppID).ToList();
            if (sup == null)
            {
                return null;
            }

            return sup;
        }

        


    }
}