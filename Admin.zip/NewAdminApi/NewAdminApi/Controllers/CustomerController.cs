﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewAdminApi.Models;

namespace NewAdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Customer")]
    public class CustomerController : Controller
    {
        private readonly SlipCartDatabaseContext db;

        public CustomerController(SlipCartDatabaseContext context)
        {
            db = context;
        }
        
        public List<Customer> CustomerGet()
        {
            var data = from x in db.Customer select x;
            return data.ToList();
        }



    }
}