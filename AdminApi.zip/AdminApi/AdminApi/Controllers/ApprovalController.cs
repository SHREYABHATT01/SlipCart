﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Approval")]
    public class ApprovalController : Controller
    {
        public SlipCartDatabaseContext db;
        public ApprovalController(SlipCartDatabaseContext context)
        {
            db = context;
        }
        //Approving Requests
        //[HttpPut]
        //public IActionResult ApproveRequest()
        //{
        //    var query=(from q in db.UserDetail
                       

        //}
        ////Rejecting requests
        //[HttpDelete]
        //public IActionResult RejectRequest()
        //{
                
        //}
    }
}