﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Leaves")]
    public class LeavesController : Controller
    {
        private readonly SlipCartDatabaseContext db;
        public LeavesController(SlipCartDatabaseContext context)
        {
            db = context;
        }

        [HttpGet]
        public IEnumerable<Leaves> Get()
        {
            return db.Leaves.ToList();
          
        }

        [HttpPost]
        public IActionResult Post([FromBody] Leaves l)
        {
            db.Add(l);
            db.SaveChanges();
            return new ObjectResult("Object has been added");
        }


        [HttpDelete("{LeaveID}")]
        public IActionResult Delete(int? LeaveID)
        {
            if (LeaveID == null)
            {
                return NotFound();
            }

            var obj = db.Leaves.Find(LeaveID);
            db.Leaves.Remove(obj);
            db.SaveChanges();
            return new ObjectResult("Deleted successfully");
        }

        [HttpPut("{LeaveID}")]
        public IActionResult Put(int LeaveID, [FromBody] Leaves l)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}

            var obj = db.Leaves.Find(LeaveID);
            if (obj == null)
            {
                return NotFound();
            }
            else
            {
                obj.IsActive = l.IsActive;
                db.SaveChanges();
                return new ObjectResult("Edited successfulky");
            }
        }
    }
}