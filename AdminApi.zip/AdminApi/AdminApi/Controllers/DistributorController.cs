﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Distributor")]
    public class DistributorController : Controller
    {
        private readonly SlipCartDatabaseContext db;
        public DistributorController(SlipCartDatabaseContext context)
        {
            db = context;
        }
        [HttpGet]
        public List<UserDetail> Get()
        {
            var dist = (from x in db.UserDetail
                        where x.UserTypeId.Equals(3)
                        select x);
            return dist.ToList();

        }

    }
}