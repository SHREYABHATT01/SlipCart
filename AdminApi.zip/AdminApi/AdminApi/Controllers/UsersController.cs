﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Users")]
    public class UsersController : Controller
    {
        private readonly SlipCartDatabaseContext db;

        
        public UsersController(SlipCartDatabaseContext context)
        {
            db = context;
        }
        [HttpGet]
        public List<UserDetail> Get()
        {
            var data = db.UserDetail.ToList();
            return data;
        }

        
    }
}