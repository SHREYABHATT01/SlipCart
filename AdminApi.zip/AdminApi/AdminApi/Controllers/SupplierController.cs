﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Supplier")]
    public class SupplierController : Controller
    {

        private readonly SlipCartDatabaseContext db;
        public SupplierController(SlipCartDatabaseContext context)
        {
            db = context;
        }

        [HttpGet]
        public List<UserDetail> Get()
        {
            var dist = (from x in db.UserDetail
                        where x.UserTypeId.Equals(2)
                        select x);
            return dist.ToList();

        }
    }
}