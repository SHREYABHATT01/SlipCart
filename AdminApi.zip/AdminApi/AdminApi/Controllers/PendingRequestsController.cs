﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using AdminApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/PendingRequests")]
    public class PendingRequestsController : Controller
    {
        private readonly SlipCartDatabaseContext db;
        public PendingRequestsController(SlipCartDatabaseContext context)
        {
            db = context;
        }
        //[HttpGet]
        //public List<UserDetail> Get()
        //{
        //    var data = (from x in db.UserDetail
        //                where x.IsActive.Equals(false)
        //                select x);
        //    return data.ToList();
        //}

        [HttpGet]
        public IEnumerable<UserDetail> Get()
        {

            return db.UserDetail;
            //    //if (u == null)
            //    //{
            //    //    return notfound();
            //    //}


        }


        [HttpPut("{id}")]
        public IActionResult put(int? id, [FromBody]UserDetail userDetail)
        {
            if (id == null)
            {
                return NotFound();
            }
            var obj = db.UserDetail.SingleOrDefault(m => m.UserId == id);
            if (obj == null)
            {
                return NotFound();
            }
            else
            {
                //obj.UserId = userDetail.UserId;
                obj.UserFirstName = userDetail.UserFirstName;
                obj.UserLastName = userDetail.UserLastName;
                obj.UserLocation = userDetail.UserLocation;
                obj.IsActive = userDetail.IsActive;
                obj.UpdatedBy = userDetail.UpdatedBy;
                obj.UpdatedDate = userDetail.UpdatedDate;
                obj.UserEmailId = userDetail.UserEmailId;
                obj.UserGender = userDetail.UserGender;
                obj.UserPermnntAddress = userDetail.UserPermnntAddress;
                obj.UserType = userDetail.UserType;
                obj.UserPassword = userDetail.UserPassword;
                obj.UserPhone = userDetail.UserPhone;
                obj.CreateDate = userDetail.CreateDate;
                obj.CreatedBy = userDetail.CreatedBy;
                obj.UserCorrspndnceAddress = userDetail.UserCorrspndnceAddress;
                obj.UserCode = userDetail.UserCode;                        
                db.SaveChanges();
                return new ObjectResult("Data Updated Successfully");

            }

        }



        //[HttpPut("{userId}")]
        //public IActionResult Put(int UserId,   UserDetail u)
        //{
        //    //if (id == null)
        //    //{
        //    //    return NotFound();
        //    //}

        //    var obj = db.UserDetail.Find(UserId);
        //    if (obj == null)
        //    {
        //        return NotFound();
        //    }
        //    else
        //    {
        //        obj.IsActive = u.IsActive;
        //        db.SaveChanges();
        //        return new ObjectResult("Edited successfulky");
        //    }
        //}

    }
}
            
                //catch (Exception ex)
                //{
                //    return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
                //}
     
    