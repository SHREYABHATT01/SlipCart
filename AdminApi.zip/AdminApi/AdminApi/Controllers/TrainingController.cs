﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AdminApi.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AdminApi.Controllers
{
    [Produces("application/json")]
    [Route("api/Training")]
    public class TrainingController : Controller
    {
        private readonly SlipCartDatabaseContext db;
        public TrainingController(SlipCartDatabaseContext context)
        {
            db = context;
        }
        [HttpGet]
        public List<Training> Get()
        {
            var train = (from x in db.Training
                        select x);
            return train.ToList();
        }

        [HttpPost]
        public IActionResult Post([FromBody] Training tr)
        {
            db.Add(tr);
            db.SaveChanges();
            return new ObjectResult("Object has been added");
        }





        [HttpDelete("{TrainingId}")]
        public IActionResult Delete(int? TrainingId)
        {
            if (TrainingId == null)
            {
                return NotFound();
            }

            var obj = db.Training.Find(TrainingId);
            db.Training.Remove(obj);
            db.SaveChanges();
            return new ObjectResult("Deleted successfully");
        }

        [HttpPut("{TrainingId}")]
        public IActionResult Put(int TrainingId, [FromBody] Training tr)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}

            var obj = db.Training.Find(TrainingId);
            if (obj == null)
            {
                return NotFound();
            }
            else
            {
                obj.TrainingCode = tr.TrainingCode;
                obj.TrainingType = tr.TrainingType;
                obj.IsActive = tr.IsActive;
                db.SaveChanges();
                return new ObjectResult("Edited successfulky");
            }
        }


    }
}