﻿using System;
using System.Collections.Generic;

namespace AdminApi.Models
{
    public partial class Products
    {
        public Products()
        {
            Inventory = new HashSet<Inventory>();
            Status = new HashSet<Status>();
        }

        public int ProdId { get; set; }
        public string ProdCode { get; set; }
        public string ProdName { get; set; }
        public int? CatId { get; set; }
        public decimal? ProdPrice { get; set; }
        public int? ProdQty { get; set; }
        public string ProdDesc { get; set; }
        public int? ReOrderLvl { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public bool? IsAlive { get; set; }

        public Category Cat { get; set; }
        public ICollection<Inventory> Inventory { get; set; }
        public ICollection<Status> Status { get; set; }
    }
}
