﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SCMWebAPI.Migrations
{
    public partial class product : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Category",
                columns: table => new
                {
                    CatID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CatCode = table.Column<string>(maxLength: 16, nullable: true),
                    CatName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Category", x => x.CatID);
                });

            migrationBuilder.CreateTable(
                name: "department",
                columns: table => new
                {
                    dept_id = table.Column<int>(nullable: false),
                    dept_name = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    manager = table.Column<string>(unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_department", x => x.dept_id);
                });

            migrationBuilder.CreateTable(
                name: "Distributor",
                columns: table => new
                {
                    DistID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    DistPassword = table.Column<string>(maxLength: 16, nullable: true),
                    DistName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    DistAddress = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    DistPhone = table.Column<int>(nullable: true),
                    DistEmailId = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Distributor", x => x.DistID);
                });

            migrationBuilder.CreateTable(
                name: "Invoice",
                columns: table => new
                {
                    InvoiceID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    InvoiceName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    InvoiceDesc = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Invoice", x => x.InvoiceID);
                });

            migrationBuilder.CreateTable(
                name: "Registration",
                columns: table => new
                {
                    RegtID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    RegtCode = table.Column<string>(maxLength: 10, nullable: false),
                    RegtName = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    RegtAddress = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    RegtCity = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    RegtPhone = table.Column<int>(nullable: true),
                    RegtEmailID = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    RegtPassword = table.Column<string>(maxLength: 16, nullable: true),
                    RegtAge = table.Column<int>(nullable: true),
                    RegtGender = table.Column<string>(unicode: false, maxLength: 1, nullable: true),
                    RegtType = table.Column<int>(nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Registration", x => x.RegtID);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    RoleID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    RoleDesc = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.RoleID);
                });

            migrationBuilder.CreateTable(
                name: "student",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false),
                    name = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    phno = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    address = table.Column<string>(unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_student", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "student1",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false),
                    name = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    phno = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    address = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    age = table.Column<int>(nullable: true),
                    batch = table.Column<string>(unicode: false, maxLength: 4, nullable: true, defaultValueSql: "('B001')")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_student1", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "student2",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false),
                    name = table.Column<string>(unicode: false, maxLength: 20, nullable: false),
                    address = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    age = table.Column<int>(nullable: true),
                    batch = table.Column<string>(unicode: false, maxLength: 4, nullable: true, defaultValueSql: "('B001')")
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_student2", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "Supplier",
                columns: table => new
                {
                    SuppID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SuppPassword = table.Column<string>(maxLength: 16, nullable: true),
                    SuppName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    SuppAddress = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    SuppPhone = table.Column<int>(nullable: true),
                    SuppEmailId = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Supplier", x => x.SuppID);
                });

            migrationBuilder.CreateTable(
                name: "UserType",
                columns: table => new
                {
                    UserTypeID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    UserType = table.Column<string>(maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserType", x => x.UserTypeID);
                });

            migrationBuilder.CreateTable(
                name: "Product",
                columns: table => new
                {
                    ProdID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CatID = table.Column<int>(nullable: true),
                    ProdCode = table.Column<string>(maxLength: 10, nullable: true),
                    ProdName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProdImage = table.Column<byte[]>(type: "image", nullable: true),
                    ProdDesc = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    ProdQty = table.Column<int>(nullable: true),
                    ProdPrice = table.Column<int>(nullable: true),
                    ReOrderLvl = table.Column<int>(nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Product", x => x.ProdID);
                    table.ForeignKey(
                        name: "FK__Product__CatID__5535A963",
                        column: x => x.CatID,
                        principalTable: "Category",
                        principalColumn: "CatID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "employee",
                columns: table => new
                {
                    id = table.Column<int>(nullable: false),
                    name = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    address = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    aged = table.Column<int>(nullable: true),
                    dept = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    salary = table.Column<int>(nullable: true),
                    dept_id = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_employee", x => x.id);
                    table.ForeignKey(
                        name: "fk",
                        column: x => x.dept_id,
                        principalTable: "department",
                        principalColumn: "dept_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserDetail",
                columns: table => new
                {
                    UserID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    UserTypeID = table.Column<int>(nullable: true),
                    UserCode = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    UserFirstName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UserLastName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UserPassword = table.Column<string>(unicode: false, maxLength: 16, nullable: true),
                    UserEmailID = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UserPhone = table.Column<int>(nullable: true),
                    UserLocation = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UserPermnntAddress = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    UserCorrspndnceAddress = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    UserGender = table.Column<string>(unicode: false, maxLength: 1, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    CreateDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserDetail", x => x.UserID);
                    table.ForeignKey(
                        name: "fk1",
                        column: x => x.UserTypeID,
                        principalTable: "UserType",
                        principalColumn: "UserTypeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProcessOrder",
                columns: table => new
                {
                    OrderID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    OrderNumber = table.Column<int>(nullable: true),
                    ProdID = table.Column<int>(nullable: true),
                    CustID = table.Column<int>(nullable: true),
                    OrderQty = table.Column<int>(nullable: false),
                    OrderAmount = table.Column<decimal>(type: "money", nullable: false),
                    Createdby = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    Updatedby = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcessOrder", x => x.OrderID);
                    table.ForeignKey(
                        name: "FK__ProcessOr__CustI__693CA210",
                        column: x => x.CustID,
                        principalTable: "Registration",
                        principalColumn: "RegtID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK__ProcessOr__ProdI__68487DD7",
                        column: x => x.ProdID,
                        principalTable: "Product",
                        principalColumn: "ProdID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Rate",
                columns: table => new
                {
                    RateID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProdID = table.Column<int>(nullable: true),
                    Tax = table.Column<int>(nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rate", x => x.RateID);
                    table.ForeignKey(
                        name: "FK__Rate__ProdID__5812160E",
                        column: x => x.ProdID,
                        principalTable: "Product",
                        principalColumn: "ProdID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Status",
                columns: table => new
                {
                    StatusID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProdID = table.Column<int>(nullable: true),
                    StatusCode = table.Column<string>(maxLength: 20, nullable: true),
                    ProdStatus = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    StatusDesc = table.Column<string>(unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Status", x => x.StatusID);
                    table.ForeignKey(
                        name: "FK__Status__ProdID__5CD6CB2B",
                        column: x => x.ProdID,
                        principalTable: "Product",
                        principalColumn: "ProdID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_employee_dept_id",
                table: "employee",
                column: "dept_id");

            migrationBuilder.CreateIndex(
                name: "IX_ProcessOrder_CustID",
                table: "ProcessOrder",
                column: "CustID");

            migrationBuilder.CreateIndex(
                name: "IX_ProcessOrder_ProdID",
                table: "ProcessOrder",
                column: "ProdID");

            migrationBuilder.CreateIndex(
                name: "IX_Product_CatID",
                table: "Product",
                column: "CatID");

            migrationBuilder.CreateIndex(
                name: "IX_Rate_ProdID",
                table: "Rate",
                column: "ProdID");

            migrationBuilder.CreateIndex(
                name: "IX_Status_ProdID",
                table: "Status",
                column: "ProdID");

            migrationBuilder.CreateIndex(
                name: "UQ__student1__751C8E546E9B3650",
                table: "student1",
                column: "address",
                unique: true,
                filter: "[address] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "uni",
                table: "student2",
                column: "address",
                unique: true,
                filter: "[address] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_UserDetail_UserTypeID",
                table: "UserDetail",
                column: "UserTypeID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Distributor");

            migrationBuilder.DropTable(
                name: "employee");

            migrationBuilder.DropTable(
                name: "Invoice");

            migrationBuilder.DropTable(
                name: "ProcessOrder");

            migrationBuilder.DropTable(
                name: "Rate");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropTable(
                name: "Status");

            migrationBuilder.DropTable(
                name: "student");

            migrationBuilder.DropTable(
                name: "student1");

            migrationBuilder.DropTable(
                name: "student2");

            migrationBuilder.DropTable(
                name: "Supplier");

            migrationBuilder.DropTable(
                name: "UserDetail");

            migrationBuilder.DropTable(
                name: "department");

            migrationBuilder.DropTable(
                name: "Registration");

            migrationBuilder.DropTable(
                name: "Product");

            migrationBuilder.DropTable(
                name: "UserType");

            migrationBuilder.DropTable(
                name: "Category");
        }
    }
}
