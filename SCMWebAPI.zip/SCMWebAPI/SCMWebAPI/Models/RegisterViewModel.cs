﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using SCMWebAPI.Models;

namespace SCMWebAPI.Models
{
    public class RegisterViewModel
    {
       
        public IFormFile ProdImage { get; set; }

    }
}
