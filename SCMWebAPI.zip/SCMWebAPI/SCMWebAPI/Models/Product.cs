﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SCMWebAPI.Models
{
    public partial class Product
    {
        public Product()
        {
           
        }

        public int ProdId { get; set; }
        public int? CatId { get; set; }
        public string ProdCode { get; set; }
        [Required(ErrorMessage = "Enter Product Name")]
        public string ProdName { get; set; }
        public byte[] ProdImage { get; set; }
        [Required]
        public string ProdDesc { get; set; }
        [Required]
        public int? ProdQty { get; set; }
        [Required]
        public int? ProdPrice { get; set; }
        public int? ReOrderLvl { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public bool? IsActive { get; set; }

        public Category Cat { get; set; }
        public ICollection<ProcessOrder> ProcessOrder { get; set; }
        public ICollection<Rate> Rate { get; set; }
        public ICollection<Status> Status { get; set; }
    }
    
}
