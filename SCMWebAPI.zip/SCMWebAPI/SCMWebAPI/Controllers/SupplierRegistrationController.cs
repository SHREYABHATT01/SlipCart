﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SCMWebAPI.Models;

namespace SCMWebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/SupplierRegistration")]
    public class SupplierRegistrationController : Controller
    {
        private readonly SlipCartDatabaseContext _context;
        public SupplierRegistrationController(SlipCartDatabaseContext context)
        {
            _context = context;
        }
        // GET: api/SupplierRegistration
        [HttpGet]
        public IEnumerable<UserDetail> GetSupplier()
        {
            return _context.UserDetail;
        }       

        // POST: api/SupplierRegistration
        [HttpPost]
        public IActionResult PostSupplier([FromBody] UserDetail user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _context.UserDetail.Add(user);
            _context.SaveChanges();
            return new ObjectResult("Data added successfully");

        }

        // PUT: api/SupplierRegistration/5
        [HttpPut("{id}")]
        public IActionResult UpdateSupplier(int? id, [FromBody]UserDetail user)
        {
            if (id == null)
            {
                return NotFound();
            }
            var obj = _context.UserDetail.SingleOrDefault(m => m.UserId == id);
            if (obj == null)
            {
                return NotFound();
            }
            else
            {
                obj.UserFirstName = user.UserFirstName;
                obj.UserLastName = user.UserLastName;
                obj.UserPassword = user.UserPassword;
                obj.UserPhone = user.UserPhone;
                obj.UserGender = user.UserGender;
                obj.UserEmailId = user.UserEmailId;
                obj.UserLocation = user.UserLocation;
                obj.UserCode = user.UserCode;
                obj.UpdatedBy = user.UpdatedBy;
                obj.UpdatedDate = user.UpdatedDate;
                obj.CreatedBy = user.CreatedBy;                        
                _context.SaveChanges();
                return new ObjectResult("Data Updated Successfully");

            }

        }

        // DELETE: api/ApiWithActions/5
      
        [HttpGet("{id}", Name = "GetSupp")]
        public UserDetail SearchSupplier(int? id)
        {
            UserDetail obj = _context.UserDetail.Find(id);
            return obj;
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult DeleteSupplier(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var obj = _context.UserDetail.Find(id);
            _context.UserDetail.Remove(obj);
            _context.SaveChanges();
            return new ObjectResult("Data Deleted Successfully");

        }
    }
}
