﻿using System;
using System.IO;

using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SCMWebAPI.Models;
using System.Net.Http;

namespace SCMWebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/Products")]
    public class ProductsController : Controller
    {
        private readonly SlipCartDatabaseContext _context;
        public ProductsController(SlipCartDatabaseContext context)
        {
            _context = context;
        }
        // GET: api/Products
        [HttpGet("{id}")]
        public Product GetProductById(int id)
        {
            return _context.Product.Find(id);
        }

        [HttpGet]
        public IEnumerable<Product> GetProduct()
        {
            return _context.Product;
        }


        //POST: api/Products
        [HttpPost]
        public IActionResult PostProduct([FromBody] Product p)
        {
            //Product p = new Product();
            //string path = "";
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _context.Product.Add(p);
            _context.SaveChanges();
            return new ObjectResult("Data Added Successfully");

        }
        //[HttpPost]
        //public async Task<IActionResult> PostProduct(RegisterViewModel file)
        //{
        //    //try
        //    //{
        //    //  RegisterViewModel r = new RegisterViewModel();
        //    Product p = new Product();
        //    if (ModelState.IsValid)
        //    {

        //        using (var memoryStream = new MemoryStream())
        //        {
        //            await file.ProdImage.CopyToAsync(memoryStream);
        //            p.ProdImage = memoryStream.ToArray();
        //        }
        //        p.ProdName = file.ProdName;
        //        _context.Product.Add(p);
        //        _context.SaveChanges();
        //        return new ObjectResult("Added");
        //    }
        //    else
        //    {
        //        return BadRequest();
        //    }
        //    //}
        //    //catch (Exception e1)
        //    //{
        //    //    return new ObjectResult(e1.Message);
        //    //}  
        //}


        // PUT: api/Products/5
        [HttpPut("{id}")]
        public IActionResult EditProduct(int ? id, [FromBody]Product product)
        {
            if(id== null)
            {
                return NotFound();
            }
            var obj = _context.Product.SingleOrDefault(m => m.ProdId == id);
            //product = obj;
            if (obj == null)
            {
                return NotFound();
            }
            else
            {

            
                obj.ProdName = product.ProdName;
                obj.ProdCode = product.ProdCode;
                obj.ProdDesc = product.ProdDesc;
                obj.CatId = product.CatId;
                obj.ProdImage = product.ProdImage;
                obj.ProdPrice = product.ProdPrice;
                obj.ProdQty = product.ProdQty;
                obj.ReOrderLvl = product.ReOrderLvl;
                obj.UpdatedBy = product.UpdatedBy;
                obj.UpdatedDate = product.UpdatedDate;
                obj.CreatedBy = product.CreatedBy;
                obj.CreatedDate = product.CreatedDate;
                _context.SaveChanges();
                return new ObjectResult("Data Updated Successfully");

            }

        }
        

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int ? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var obj = _context.Product.Find(id);
            _context.Product.Remove(obj);
            _context.SaveChanges();
            return new ObjectResult("Data Deleted Successfully");

        }

     
    }
}
