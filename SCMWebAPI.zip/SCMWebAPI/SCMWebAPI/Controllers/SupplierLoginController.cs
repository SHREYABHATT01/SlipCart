﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SCMWebAPI.Models;

namespace SCMWebAPI.Controllers
{
    [Produces("application/json")]
    [Route("api/SupplierLogin")]
    public class SupplierLoginController : Controller
    {
        private readonly SlipCartDatabaseContext _context;
        public SupplierLoginController(SlipCartDatabaseContext context)
        {
            _context = context;
        }
        // GET: api/SupplierLogin
        [HttpGet]
        public IEnumerable<UserDetail> Get()
        {
            return _context.UserDetail;
        }

        // GET: api/SupplierLogin/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }
        
        // POST: api/SupplierLogin
       
        //public void Post([FromBody]string value)
        //{
        //}
        
        //// PUT: api/SupplierLogin/5
        //[HttpPut("{id}")]
        //public void Put(int id, [FromBody]string value)
        //{
        //}
        
        //// DELETE: api/ApiWithActions/5
        //[HttpDelete("{id}")]
        //public void Delete(int id)
        //{
        //}
        [HttpPost]
        
        public  IActionResult SupplierLogin([FromBody] UserDetail userlogin)
        {
            if (userlogin.UserEmailId != null)
            {
                if (ModelState.IsValid) // this is check validity
                {
                    var obj = _context.UserDetail.Where(a => a.UserEmailId.Equals(userlogin.UserEmailId)
                    && a.UserPassword.Equals(userlogin.UserPassword))
                        .FirstOrDefault();

                    if (obj != null)
                    {
                        return new ObjectResult("Login Successfully");
                        //return RedirectToPage("http://localhost:51742/Products/GetProduct");

                    }
                    else return NotFound();
                }
                return NotFound();
            }
            else
            {
                return new ObjectResult("Please Enter your EmailID");

            }


        }
    }
}
