﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;
using WebAPIRegisterforErpProject.Models;
using ComsumeWebApi.Models;
using Microsoft.AspNetCore.Http;

namespace ComsumeWebApi.Controllers
{
    public class ProductDetailsController : Controller
    {
        List<Product> list;
        public IActionResult Index()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:51094/api/");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage res = client.GetAsync("Product").Result;
            if (res.IsSuccessStatusCode)
            {
                // ViewBag.res = res.Content.ReadAsAsync<IEnumerable<Product>>().Result;
                 list = res.Content.ReadAsAsync<IEnumerable<Product>>().Result.ToList();

            }
            else
            {
                ViewBag.res = "Error";
            }
            return View(list);
        }

        public IActionResult GetProduct()
        { 
            return View();
        }

        public IActionResult GetProductById(int id)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:51094/api/");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage res = client.GetAsync("PRODUCT/" + id).Result;
            if (res.IsSuccessStatusCode)
            {
                ViewBag.res = res.Content.ReadAsAsync<Product>().Result;

            }
            else
            {
                ViewBag.res = "Error";
            }
            return View();
        }
        private int isExisting(int id)
        {
            List<Cart> cart = HttpContext.Session.GetComplexData<List<Cart>>("cart") ?? new List<Cart>();
            for (int i=0;i<cart.Count;i++)
            

                if(cart[i].Product.ProdId==id)
               
                    return i;
            return -1;

            


        }



        public IActionResult Order(int id)
        {
            //const string SessionKeyName = "_Name";

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:51094/api/");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage res = client.GetAsync("Product").Result;
            if (res.IsSuccessStatusCode)
            {
                // ViewBag.res = res.Content.ReadAsAsync<IEnumerable<Product>>().Result;
                list = res.Content.ReadAsAsync<IEnumerable<Product>>().Result.ToList();

            }


            //ViewBag.c = list.Count();

            List<Cart> cart = HttpContext.Session.GetComplexData<List<Cart>>("cart") ?? new List<Cart>();
        
            if (cart == null || cart.Count==0)
            {
               
                //HttpContext.Session.SetString(SessionKeyName, Guid.NewGuid().ToString());
                 Product p = (from data in list where data.ProdId == id select data).FirstOrDefault();
                if(p!=null)
               ViewBag.p ="not found";
                cart.Add(new Cart(p, 1));
                HttpContext.Session.SetComplexData("cart", cart);

            }
            else
            {
                  cart = HttpContext.Session.GetComplexData<List<Cart>>("cart") ?? new List<Cart>();
                int index = isExisting(id);
                if (index == -1)
                {
                    var p = (from data in list where data.ProdId == id select data).FirstOrDefault();
                    cart.Add(new Cart(p, 1));
                }
                else
                    cart[index].Qty1++;
                HttpContext.Session.SetComplexData("cart", cart);

            }
           
          
            return View("Cart",cart);

        }





    public ActionResult OrderDelete(int id)
        {
            int index = isExisting(id);
            List<Cart> cart = HttpContext.Session.GetComplexData<List<Cart>>("cart") ?? new List<Cart>();
            cart.RemoveAt(index);
            HttpContext.Session.SetComplexData("cart", cart); 
            return View("Cart",cart);

        }




    }

   

}