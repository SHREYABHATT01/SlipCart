﻿namespace ComsumeWebApi.Controllers
{
    internal class UserDetail
    {
    }
}