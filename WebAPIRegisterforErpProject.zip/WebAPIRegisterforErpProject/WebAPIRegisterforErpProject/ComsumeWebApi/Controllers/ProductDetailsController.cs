﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Headers;
using WebAPIRegisterforErpProject.Models;

namespace ComsumeWebApi.Controllers
{
    public class ProductDetailsController : Controller
    {
        public IActionResult Index()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:51094/api/");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage res = client.GetAsync("Product").Result;
            if (res.IsSuccessStatusCode)
            {
                ViewBag.res = res.Content.ReadAsAsync<IEnumerable<Product>>().Result;

            }
            else
            {
                ViewBag.res = "Error";
            }
            return View();
        }

        public IActionResult GetProduct()
        { 
            return View();
        }

        public IActionResult GetProductById(int id)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:51094/api/");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage res = client.GetAsync("PRODUCT/" + id).Result;
            if (res.IsSuccessStatusCode)
            {
                ViewBag.res = res.Content.ReadAsAsync<Product>().Result;

            }
            else
            {
                ViewBag.res = "Error";
            }
            return View();
        }
    }

   

}