﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIRegisterforErpProject.Models
{
    public class Cart
    {
        int Qty { get; set; }
        List<Product> productList { get; set; }
        private Product product = new Product();
        public Cart()
        {


        }
        // public Cart(Product product,int qty)
        //{
        //    Cart.Qty = qty;
           
        //}
    }
}
