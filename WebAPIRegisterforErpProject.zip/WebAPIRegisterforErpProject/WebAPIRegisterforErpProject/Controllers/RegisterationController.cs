﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPIRegisterforErpProject.Models;
namespace WebAPIRegisterforErpProject.Controllers
{
    [Produces("application/json")]
    [Route("api/Registeration")]
    public class RegisterationController : Controller
    {

        private readonly SlipCartDatabaseContext   db;
        public RegisterationController(SlipCartDatabaseContext context)
        {
            db = context;
        }
        // GET: api/Registeration
        [HttpGet]
        public IEnumerable<UserDetail> Get()
        {
            return db.UserDetail.ToList();
        }

        // GET: api/Registeration/5
        [HttpGet("{id}")]
        public UserDetail Get(int id)
        {
            UserDetail userDetail = db.UserDetail.Find(id);
            return userDetail;
        }
        
        // POST: api/Registeration
        [HttpPost]
        public void Post([FromBody]UserDetail user)
        {
            db.Add(user);
            db.SaveChanges();
        }
        
        // PUT: api/Registeration/5
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]UserDetail user)
        {

#pragma warning disable CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
            if (id == null)
#pragma warning restore CS0472 // The result of the expression is always the same since a value of this type is never equal to 'null'
            {
                return NotFound();
            }

            var obj = db.UserDetail.SingleOrDefault(m => m.UserId == id);
            if (obj == null)
            {
                return NotFound();
            }
            else
            {
             
                obj.UserFirstName =user.UserFirstName;
                obj.UserLastName = user.UserLastName;
                obj.UserEmailId = user.UserEmailId;
                obj.UserPhone = user.UserPhone;
                obj.UserLocation = user.UserLocation;
                obj.UserPermnntAddress = user.UserPermnntAddress;
                obj.UserCorrspndnceAddress = user.UserCorrspndnceAddress;
                obj.UserGender = user.UserGender;
                obj.CreatedBy = user.CreatedBy;
                obj.CreateDate = user.CreateDate;
                obj.UpdatedBy = user.UpdatedBy;
                obj.UpdatedDate = user.UpdatedDate;
                obj.IsActive = user.IsActive;
                db.SaveChanges();
                return new ObjectResult("Edited successfully");
            }
        }
   
        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            UserDetail user = db.UserDetail.Find(id);
            db.Remove(user);
            db.SaveChanges();
        }


    }
}
