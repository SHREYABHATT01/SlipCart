﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPIRegisterforErpProject.Models;
namespace WebAPIRegisterforErpProject.Controllers
{
    [Route("api/[Controller]")]
    [Produces("application/json")]
    //[Route("api/Login")]
    public class LoginController : Controller
    {
        private readonly SlipCartDatabaseContext _context;
        public LoginController(SlipCartDatabaseContext context)
        {
            _context = context;
        }

        // GET: api/Login
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Login/5
        [HttpGet("{id}", Name = "Get")]
        public string Get(int id)
        {
            return "value";
        }
        
        // POST: api/Login
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }
        
        // PUT: api/Login/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }
        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
        [HttpPost]

        public ActionResult SupplierLogin([FromBody] UserDetail userlogin)
        {
            if (userlogin.UserEmailId != null)
            {
                if (ModelState.IsValid) 
                {
                    var obj = _context.UserDetail.Where(a => a.UserEmailId.Equals(userlogin.UserEmailId)
                    && a.UserPassword.Equals(userlogin.UserPassword))
                        .FirstOrDefault();

                    if (obj != null)
                    {
                        return new ObjectResult("Login Successfully");
                    }
                    else return NotFound();

                }
                return View(userlogin);
            }
            else
            {
                return new ObjectResult("Please Enter your EmailID");
            }
        }



    }
}
