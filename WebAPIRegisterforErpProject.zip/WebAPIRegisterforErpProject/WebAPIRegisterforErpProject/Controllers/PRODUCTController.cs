﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPIRegisterforErpProject.Models;


namespace WebAPIRegisterforErpProject.Controllers
{
    [Route("api/[Controller]")]
    [Produces("application/json")]
    //[Route("api/PRODUCT")]
    public class PRODUCTController : Controller
    {
        private readonly SlipCartDatabaseContext db;
        public PRODUCTController(SlipCartDatabaseContext context)
        {
            db = context;
        }

        // GET: api/PRODUCT
        [HttpGet]
        public IEnumerable<Product> Get()
        {
            return db.Product.ToList();
        }

        // GET: api/PRODUCT/5
        [HttpGet("{id}")]
        public Product Get(int id)
        {
            Product product = db.Product.Find(id);
            return product;
        }

        [HttpGet]
        [Route("Details/{Productname}")]
        public IEnumerable<Product> GetproductbyNAME(string  Productname)
        {
            //return _context.ItemDetails.Where(i => i.Item_ID == id).ToList(); ;  
            return db.Product.Where(i => i.ProdName.Contains(Productname)).ToList();
        }



        // POST: api/PRODUCT
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }
        
        // PUT: api/PRODUCT/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }
        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
        //[HttpPost]

        //public string OrderNow(int id)
        //{
        //    List<Cart> cart = new List<Cart>();
        //    var x = HttpContext.Session.GetComplexData<Cart>("cart");
        //    if(x==null)
        //    {
        //        List<Cart> cart = new List<Cart>();
        //        cart.Add(new Cart(db.Product.Find(id), 1));
        //        HttpContext.Session.SetComplexData("cart", cart);

        //    }
        //    else
        //    {
                
        //            cart = HttpContext.Session.GetComplexData<Cart>("cart");
        //        x= HttpContext.Session.GetComplexData<Cart>("cart");
        //    }
            
        //    return x.ToString();


        //}
        public ActionResult displaycart()
        {



            return View();
        }
    }
}
