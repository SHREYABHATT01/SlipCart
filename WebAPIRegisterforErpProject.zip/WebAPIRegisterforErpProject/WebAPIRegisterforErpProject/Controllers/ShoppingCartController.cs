﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPIRegisterforErpProject.Models;

namespace WebAPIRegisterforErpProject.Controllers
{
    [Produces("application/json")]
    [Route("api/ShoppingCart")]
    public class ShoppingCartController : Controller
    {
        private readonly SlipCartDatabaseContext db;
        public ShoppingCartController(SlipCartDatabaseContext context)
        {
            db = context;
        }




    }
}