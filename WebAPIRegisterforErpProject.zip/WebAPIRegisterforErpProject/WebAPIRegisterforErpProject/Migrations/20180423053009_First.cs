﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace WebAPIRegisterforErpProject.Migrations
{
    public partial class First : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Category",
                columns: table => new
                {
                    CatID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CatCode = table.Column<string>(maxLength: 16, nullable: true),
                    CatName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Category", x => x.CatID);
                });

            migrationBuilder.CreateTable(
                name: "Distributor",
                columns: table => new
                {
                    DistID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    DistAddress = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    DistEmailId = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    DistName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    DistPassword = table.Column<string>(maxLength: 16, nullable: true),
                    DistPhone = table.Column<int>(nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Distributor", x => x.DistID);
                });

            migrationBuilder.CreateTable(
                name: "Invoice",
                columns: table => new
                {
                    InvoiceID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    InvoiceDesc = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    InvoiceName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Invoice", x => x.InvoiceID);
                });

            migrationBuilder.CreateTable(
                name: "Registration",
                columns: table => new
                {
                    RegtID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    RegtAddress = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    RegtAge = table.Column<int>(nullable: true),
                    RegtCity = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    RegtCode = table.Column<string>(maxLength: 10, nullable: false),
                    RegtEmailID = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    RegtGender = table.Column<string>(type: "char(1)", nullable: true),
                    RegtName = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    RegtPassword = table.Column<string>(maxLength: 16, nullable: true),
                    RegtPhone = table.Column<int>(nullable: true),
                    RegtType = table.Column<int>(nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Registration", x => x.RegtID);
                });

            migrationBuilder.CreateTable(
                name: "Role",
                columns: table => new
                {
                    RoleID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    IsActive = table.Column<bool>(nullable: true),
                    RoleDesc = table.Column<string>(unicode: false, maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Role", x => x.RoleID);
                });

            migrationBuilder.CreateTable(
                name: "Supplier",
                columns: table => new
                {
                    SuppID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    SuppAddress = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    SuppEmailId = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    SuppName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    SuppPassword = table.Column<string>(maxLength: 16, nullable: true),
                    SuppPhone = table.Column<int>(nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Supplier", x => x.SuppID);
                });

            migrationBuilder.CreateTable(
                name: "UserType",
                columns: table => new
                {
                    UserTypeID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    IsActive = table.Column<bool>(nullable: true),
                    UserType = table.Column<string>(maxLength: 20, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserType", x => x.UserTypeID);
                });

            migrationBuilder.CreateTable(
                name: "Product",
                columns: table => new
                {
                    ProdID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CatID = table.Column<int>(nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    ProdCode = table.Column<string>(maxLength: 10, nullable: false),
                    ProdDesc = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    ProdName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    ProdPrice = table.Column<int>(nullable: true),
                    ProdQty = table.Column<int>(nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Product", x => x.ProdID);
                    table.ForeignKey(
                        name: "FK__Product__CatID__693CA210",
                        column: x => x.CatID,
                        principalTable: "Category",
                        principalColumn: "CatID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "UserDetail",
                columns: table => new
                {
                    UserID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreateDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    UserCode = table.Column<string>(unicode: false, maxLength: 10, nullable: true),
                    UserCorrspndnceAddress = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    UserEmailID = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    UserFirstName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UserGender = table.Column<string>(type: "char(1)", nullable: true),
                    UserLastName = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UserLocation = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UserPassword = table.Column<string>(nullable: true),
                    UserPermnntAddress = table.Column<string>(unicode: false, maxLength: 50, nullable: true),
                    UserPhone = table.Column<int>(nullable: true),
                    UserTypeID = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserDetail", x => x.UserID);
                    table.ForeignKey(
                        name: "fk",
                        column: x => x.UserTypeID,
                        principalTable: "UserType",
                        principalColumn: "UserTypeID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "ProcessOrder",
                columns: table => new
                {
                    OrderID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Createdby = table.Column<string>(unicode: false, maxLength: 30, nullable: true),
                    CustID = table.Column<int>(nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    OrderAmount = table.Column<decimal>(type: "money", nullable: false),
                    OrderNumber = table.Column<int>(nullable: true),
                    OrderQty = table.Column<int>(nullable: false),
                    ProdID = table.Column<int>(nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    Updatedby = table.Column<string>(unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProcessOrder", x => x.OrderID);
                    table.ForeignKey(
                        name: "FK__ProcessOr__CustI__01142BA1",
                        column: x => x.CustID,
                        principalTable: "Registration",
                        principalColumn: "RegtID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK__ProcessOr__ProdI__00200768",
                        column: x => x.ProdID,
                        principalTable: "Product",
                        principalColumn: "ProdID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Rate",
                columns: table => new
                {
                    RateID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CreatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime", nullable: true),
                    IsActive = table.Column<bool>(nullable: true),
                    ProdID = table.Column<int>(nullable: true),
                    Tax = table.Column<int>(nullable: true),
                    UpdatedBy = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    UpdatedDate = table.Column<DateTime>(type: "datetime", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rate", x => x.RateID);
                    table.ForeignKey(
                        name: "FK__Rate__ProdID__6C190EBB",
                        column: x => x.ProdID,
                        principalTable: "Product",
                        principalColumn: "ProdID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Status",
                columns: table => new
                {
                    StatusID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    ProdID = table.Column<int>(nullable: true),
                    ProdStatus = table.Column<string>(unicode: false, maxLength: 20, nullable: true),
                    StatusCode = table.Column<string>(maxLength: 20, nullable: true),
                    StatusDesc = table.Column<string>(unicode: false, maxLength: 30, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Status", x => x.StatusID);
                    table.ForeignKey(
                        name: "FK__Status__ProdID__71D1E811",
                        column: x => x.ProdID,
                        principalTable: "Product",
                        principalColumn: "ProdID",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ProcessOrder_CustID",
                table: "ProcessOrder",
                column: "CustID");

            migrationBuilder.CreateIndex(
                name: "IX_ProcessOrder_ProdID",
                table: "ProcessOrder",
                column: "ProdID");

            migrationBuilder.CreateIndex(
                name: "IX_Product_CatID",
                table: "Product",
                column: "CatID");

            migrationBuilder.CreateIndex(
                name: "IX_Rate_ProdID",
                table: "Rate",
                column: "ProdID");

            migrationBuilder.CreateIndex(
                name: "IX_Status_ProdID",
                table: "Status",
                column: "ProdID");

            migrationBuilder.CreateIndex(
                name: "IX_UserDetail_UserTypeID",
                table: "UserDetail",
                column: "UserTypeID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Distributor");

            migrationBuilder.DropTable(
                name: "Invoice");

            migrationBuilder.DropTable(
                name: "ProcessOrder");

            migrationBuilder.DropTable(
                name: "Rate");

            migrationBuilder.DropTable(
                name: "Role");

            migrationBuilder.DropTable(
                name: "Status");

            migrationBuilder.DropTable(
                name: "Supplier");

            migrationBuilder.DropTable(
                name: "UserDetail");

            migrationBuilder.DropTable(
                name: "Registration");

            migrationBuilder.DropTable(
                name: "Product");

            migrationBuilder.DropTable(
                name: "UserType");

            migrationBuilder.DropTable(
                name: "Category");
        }
    }
}
