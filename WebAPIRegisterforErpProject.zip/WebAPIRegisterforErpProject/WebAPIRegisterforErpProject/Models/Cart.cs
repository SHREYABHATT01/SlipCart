﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPIRegisterforErpProject.Models
{
    public class Cart
    {
        int Qty;
        public Product Product { get => product; set => product = value; }
        public int Qty1 { get => Qty; set => Qty = value; }

        private Product product = new Product();
        public Cart()
        {


        }
         public Cart(Product product,int qty)
        {
            this.Qty1 = qty;
            this.Product = product;
           
        }
    }
}
