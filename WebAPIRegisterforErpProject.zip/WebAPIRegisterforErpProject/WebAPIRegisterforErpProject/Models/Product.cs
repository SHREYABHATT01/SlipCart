﻿using System;
using System.Collections.Generic;

namespace WebAPIRegisterforErpProject.Models
{
    public partial class Product
    {
        public Product()
        {
            ProcessOrder = new HashSet<ProcessOrder>();
            Rate = new HashSet<Rate>();
            Status = new HashSet<Status>();
        }

        public int ProdId { get; set; }
        public int? CatId { get; set; }
        public string ProdCode { get; set; }
        public string ProdName { get; set; }
        public string ProdDesc { get; set; }
        public int? ProdQty { get; set; }
        public int? ProdPrice { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public bool? IsActive { get; set; }

        public Category Cat { get; set; }
        public ICollection<ProcessOrder> ProcessOrder { get; set; }
        public ICollection<Rate> Rate { get; set; }
        public ICollection<Status> Status { get; set; }
    }
}
