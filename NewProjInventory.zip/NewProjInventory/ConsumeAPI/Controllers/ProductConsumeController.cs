﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ConsumeAPI.Controllers
{
    public class ProductConsumeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Display()
        {
            return View();
        }

        public IActionResult Search()
        {
            return View();
        }

        public IActionResult Update()
        {
            return View();
        }

        public IActionResult ReOrder()
        {
            return View();
        }
    }
}