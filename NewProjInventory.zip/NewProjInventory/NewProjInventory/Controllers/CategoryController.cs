﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewProjInventory.Models;

namespace NewProjInventory.Controllers
{
    [Produces("application/json")]
    [Route("api/Category")]
    public class CategoryController : Controller
    {
        private readonly SlipCartDatabaseContext db;

        public CategoryController(SlipCartDatabaseContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public List<Category> GetCategory()
        {
            return db.Category.ToList();

        }

        [HttpGet("{Name}", Name = "Get")]
        public List<Category> Details(string Name)
        {
            List<Category> arr = new List<Category>();

            IQueryable<Category> list = db.Category.Where(d => d.CatName.Equals(Name));
            foreach(var z in list)
            {
                arr.Add(z);

            }
            return arr;
        }

        [HttpPost]
        public IActionResult Post([FromBody] Category cat)

        {
            db.Add(cat);
            db.SaveChanges();
            return new ObjectResult("Object has been added");

        }


    }
}
