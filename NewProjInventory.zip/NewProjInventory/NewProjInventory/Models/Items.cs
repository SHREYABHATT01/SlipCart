﻿using System;
using System.Collections.Generic;

namespace NewProjInventory.Models
{
    public partial class Items
    {
        public int ItemId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public int? ItemQty { get; set; }
        public string ItemDesc { get; set; }
        public int? ItemPrice { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool? IsActive { get; set; }
    }
}
