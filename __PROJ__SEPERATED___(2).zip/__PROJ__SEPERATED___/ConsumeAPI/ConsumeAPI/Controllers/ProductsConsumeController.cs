﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using NewProjInventory.Models;

namespace ConsumeAPI.Controllers
{
    public class ProductsConsumeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        /* Display Products Record */
        public IActionResult Show_Result()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:50086/api/");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage res = client.GetAsync("Products").Result;

            if (res.IsSuccessStatusCode)
            {
                ViewBag.res = res.Content.ReadAsAsync<IEnumerable<Product>>().Result;

            }
            else
            {
                ViewBag.res = "Error";
            }

            return View();
        }

        /* Update/Edit Products Record */
        public ActionResult EditProductID(int? id)

        {
            ViewBag.id = id;
            return View();

        }

        ///*Add new Product*/
        //public ActionResult Add_Record_Product()
        //{
        //    return View();

        //}


        public IActionResult Search()
        {
            return View();
        }
    }
}