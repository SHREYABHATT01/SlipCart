﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewProjInventory.Models;

namespace NewProjInventory.Controllers
{
    [Produces("application/json")]
    [Route("api/Products")]
    public class ProductsController : Controller
    {
        private readonly SlipCartDatabaseContext db;

        public ProductsController(SlipCartDatabaseContext db)
        {
            this.db = db;
        }

        /*List out all products*/

        [HttpGet]
        public List<Product> GetProducts()
        {
            return db.Product.ToList();
        }

        //Select from table, find by name
        [HttpGet("{Name}", Name = "Get")]
        public List<Product> Details(string Name)
        {
            List<Product> arr = new List<Product>();

            IQueryable<Product> list = db.Product.Where(d => d.ProdName.Equals(Name));
            foreach (var x in list)
            {
                arr.Add(x);
            }

            return arr;
        }

        /*Insert record products*/
        public IActionResult PostProduct([FromBody] Product p)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            db.Product.Add(p);
            db.SaveChanges();
            return new ObjectResult("Data Added Successfully");

        }

        /*Update record in products table*/

        [HttpPut("{id}")]
        public IActionResult EditProduct(int? id, [FromBody]Product product)
        {
            if (id == null)
            {
                return NotFound();
            }
            var obj = db.Product.SingleOrDefault(m => m.ProdId == id);
            if (obj == null)
            {
                return NotFound();
            }
            else
            {

                obj.ProdName = product.ProdName;
                obj.ProdCode = product.ProdCode;
                obj.ProdDesc = product.ProdDesc;
                obj.CatId = product.CatId;
                obj.ProdImage = product.ProdImage;
                obj.ProdPrice = product.ProdPrice;
                obj.ProdQty = product.ProdQty;
                obj.ReOrderlvl = product.ReOrderlvl;
                obj.UpdatedBy = product.UpdatedBy;
                obj.UpdatedDate = product.UpdatedDate;
                obj.CreatedBy = product.CreatedBy;
                obj.CreatedDate = product.CreatedDate;
                db.SaveChanges();
                return new ObjectResult("Data Updated Successfully");

            }

        }

        /*Delete from products table*/

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public IActionResult DeleteProduct(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var obj = db.Product.Find(id);
            db.Product.Remove(obj);
            db.SaveChanges();
            return new ObjectResult("Data Deleted Successfully");

        }

    }
}