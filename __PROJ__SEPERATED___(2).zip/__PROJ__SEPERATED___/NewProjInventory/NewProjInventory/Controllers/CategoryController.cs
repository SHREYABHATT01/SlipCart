﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewProjInventory.Models;

namespace NewProjInventory.Controllers
{
    [Produces("application/json")]
    [Route("api/Category")]
    public class CategoryController : Controller
    {
        private readonly SlipCartDatabaseContext db;

        public CategoryController(SlipCartDatabaseContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public List<Category> GetCategories()
        {
            return db.Category.ToList();
        }

        [HttpGet("{Name}", Name = "GetName")]
        public List<Product> Details(string Name)
        {

            List<Product> arr1 = new List<Product>();

            var id =
                     (from c in db.Category
                      where c.CatName == Name
                      select c.CatId).FirstOrDefault();
            IQueryable<Product> list = db.Product.Where(d => d.CatId.Equals(id));

            foreach (var x in list)
            {
                arr1.Add(x);
            }
            return arr1;
        }

       
    }
}