﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NewProjInventory.Models;

namespace NewProjInventory.Controllers
{
    [Produces("application/json")]
    [Route("api/Products")]
    public class ProductsController : Controller
    {
        private readonly SlipCartDatabaseContext db;

        public ProductsController(SlipCartDatabaseContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public List<Product> GetProducts()
        {
            return db.Product.ToList();
        }

        //Select from table, find by name
        [HttpGet("{Name}", Name="Get")]
        public List<Product> Details(string Name)
        {
            List<Product> arr = new List<Product>();

            IQueryable<Product> list = db.Product.Where(d => d.ProdName.Equals(Name));
            foreach(var x in list)
            {
                arr.Add(x);
            }

            return arr;
        }

    }
}