﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ProcessOrder.Models;

namespace ProcessOrder.Controllers
{
    [Produces("application/json")]
    [Route("api/ProcessOrder")]
    public class ProcessOrderController : Controller
    {

        private readonly SlipCartDatabaseContext db;

        public ProcessOrderController(SlipCartDatabaseContext db)
        {
            this.db = db;
        }


        // fetching all  Orders
        [HttpGet]
        public List<ProcessOrder.Models.ProcessOrder> GetOrder()
        {
            return db.ProcessOrder.ToList();
        }




        // Creating a Purchase Order
        [HttpPost]
        public IActionResult PostOrder([FromBody] ProcessOrder.Models.ProcessOrder p)
        {
            db.Add(p);
            db.SaveChanges();
            return new ObjectResult("Object has been added");
        }



        
    }
}