﻿using System;
using System.Collections.Generic;

namespace SCMWebAPI.Models
{
    public partial class Registration
    {
        public Registration()
        {
            ProcessOrder = new HashSet<ProcessOrder>();
        }

        public int RegtId { get; set; }
        public string RegtCode { get; set; }
        public string RegtName { get; set; }
        public string RegtAddress { get; set; }
        public string RegtCity { get; set; }
        public int? RegtPhone { get; set; }
        public string RegtEmailId { get; set; }
        public string RegtPassword { get; set; }
        public int? RegtAge { get; set; }
        public string RegtGender { get; set; }
        public int? RegtType { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string UpdatedBy { get; set; }
        public bool? IsActive { get; set; }

        public ICollection<ProcessOrder> ProcessOrder { get; set; }
    }
}
