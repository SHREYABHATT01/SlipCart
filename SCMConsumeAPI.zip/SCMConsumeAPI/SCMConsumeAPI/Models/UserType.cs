﻿using System;
using System.Collections.Generic;

namespace SCMWebAPI.Models
{
    public partial class UserType
    {
        public UserType()
        {
            UserDetail = new HashSet<UserDetail>();
        }

        public int UserTypeId { get; set; }
        public string UserType1 { get; set; }
        public bool? IsActive { get; set; }

        public ICollection<UserDetail> UserDetail { get; set; }
    }
}
