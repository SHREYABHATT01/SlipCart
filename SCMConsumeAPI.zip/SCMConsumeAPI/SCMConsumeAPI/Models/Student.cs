﻿using System;
using System.Collections.Generic;

namespace SCMWebAPI.Models
{
    public partial class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Phno { get; set; }
        public string Address { get; set; }
    }
}
