﻿using System;
using System.Collections.Generic;

namespace SCMWebAPI.Models
{
    public partial class ProcessOrder
    {
        public int OrderId { get; set; }
        public int? OrderNumber { get; set; }
        public int? ProdId { get; set; }
        public int? CustId { get; set; }
        public int OrderQty { get; set; }
        public decimal OrderAmount { get; set; }
        public string Createdby { get; set; }
        public string Updatedby { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public bool? IsActive { get; set; }

        public Registration Cust { get; set; }
        public Product Prod { get; set; }
    }
}
