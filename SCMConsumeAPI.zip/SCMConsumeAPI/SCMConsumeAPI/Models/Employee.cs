﻿using System;
using System.Collections.Generic;

namespace SCMWebAPI.Models
{
    public partial class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int? Aged { get; set; }
        public string Dept { get; set; }
        public int? Salary { get; set; }
        public int? DeptId { get; set; }

        public Department DeptNavigation { get; set; }
    }
}
