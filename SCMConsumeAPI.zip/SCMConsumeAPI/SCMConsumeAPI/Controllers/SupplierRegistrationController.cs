﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace SCMConsumeAPI.Controllers
{
    public class SupplierRegistrationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult PostSupplier()
        {
            return View();
        }
    }
}