﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SCMWebAPI.Models;
using SCMConsumeAPI.Models;

namespace SCMConsumeAPI.Controllers
{
    public class ProductsController : Controller
    {
        private IHostingEnvironment _hostingEnv;
        public ProductsController(IHostingEnvironment hostingEnv)
        {
            _hostingEnv = hostingEnv;
        }

  

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult GetProduct()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("http://localhost:51362/api/");
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage res = client.GetAsync("Products").Result;
            if (res.IsSuccessStatusCode)
            {
                ViewBag.res = res.Content.ReadAsAsync<IEnumerable<Product>>().Result;

            }
            else
            {
                ViewBag.res = "Error";
            }
            return View();

        }

        public ActionResult PostProduct()
        {
            return View();

        }
        //public ActionResult EditProduct(int id)
        //{
        //    ViewBag.id = id; // HttpContext.Request.Query["id"];
        //  //int i1d= Convert.ToInt16( HttpContext.Request.Query["id"]);
        //  //  ViewBag.id = i1d;

        //    return View();

        //}
        public ActionResult SearchProduct()
        {
            return View();

        }
        [HttpGet]
        public ActionResult EditProductID(int? id)

        {
            ViewBag.id = id;
            return View();

        }

    }
}